// export const BASE_URL = 'https://uk1.ukvehicledata.co.uk/api/';

export const BASE_URL = 'https://uk1.ukvehicledata.co.uk/api/datapackage/VehicleData?v=2&api_nullitems=1&auth_apikey=af1eed98-d531-46af-9d65-fb3a178f9f58&key_VRM=';